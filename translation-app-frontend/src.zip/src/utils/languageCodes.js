// src/utils/languageCodes.js

export const languageCodeMap = {
    'English': 'en-US',
    'Spanish': 'es-ES',
    'French': 'fr-FR',
    'Chinese': 'zh-CN',
    // Add more languages as needed
  };
  